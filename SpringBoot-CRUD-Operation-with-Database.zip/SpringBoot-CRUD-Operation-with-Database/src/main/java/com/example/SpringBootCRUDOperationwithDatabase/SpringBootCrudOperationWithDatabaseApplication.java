package com.example.SpringBootCRUDOperationwithDatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudOperationWithDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudOperationWithDatabaseApplication.class, args);
	}

}

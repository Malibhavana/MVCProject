package com.MyFirstApplication.APIProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

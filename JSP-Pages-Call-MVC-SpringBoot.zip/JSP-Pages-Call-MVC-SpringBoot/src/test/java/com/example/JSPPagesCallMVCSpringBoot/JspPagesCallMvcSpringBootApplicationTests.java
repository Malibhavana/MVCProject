package com.example.JSPPagesCallMVCSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JspPagesCallMvcSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}

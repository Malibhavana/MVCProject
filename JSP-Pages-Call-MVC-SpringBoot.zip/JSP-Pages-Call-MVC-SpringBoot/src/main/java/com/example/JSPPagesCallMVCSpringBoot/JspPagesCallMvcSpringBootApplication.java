package com.example.JSPPagesCallMVCSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JspPagesCallMvcSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(JspPagesCallMvcSpringBootApplication.class, args);
	}

}

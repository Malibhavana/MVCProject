package com.example.JSPpagescallwithspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JspPagesCallWithSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(JspPagesCallWithSpringbootApplication.class, args);
	}

}
